// Fichier Global.h

#ifndef GLOBAL_H
#define GLOBAL_H

extern int Figure;

#endif
