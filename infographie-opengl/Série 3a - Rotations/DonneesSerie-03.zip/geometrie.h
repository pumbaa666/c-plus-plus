// Fichier Geometrie.h

#ifndef GEOMETRIE_H
#define GEOMETRIE_H

void DessinerLaScene();
void DessinerLesAxes();

#endif

