// Fichier Evenements.h

#ifndef EVENEMENTS_H
#define EVENEMENTS_H

void Display();
void Reshape(int, int);
void Mouse(int, int, int, int);
void Motion(int, int);

#endif

