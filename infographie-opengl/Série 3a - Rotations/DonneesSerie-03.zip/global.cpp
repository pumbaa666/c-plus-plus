// Fichier Global.cpp

#include <GL\glut.h>

int Figure = 1;

