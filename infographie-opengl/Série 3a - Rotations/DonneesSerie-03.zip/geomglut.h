// Fichier Geoglut.h

#ifndef GEOMGLUT_H
#define GEOMGLUT_H

void myinit();

#endif
