/*Ce fichier contient l'impl�mentation de la classe CourbeBezier
**Projet de POO 2001 : Listes d'objets 3D
**Auteurs : Avril   BLAISE
**          Thomas  ROUCH
**          Cyrille HEIT
**ESIL, D�partement ES2I, Promotion 2002
*/

#include "CourbeBezier.h"

FXIMPLEMENT(CourbeBezier,CourbeNURBS,NULL,0)

CourbeBezier::CourbeBezier()
{

}

CourbeBezier::~CourbeBezier()
{

}
