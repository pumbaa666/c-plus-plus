/*Ce fichier contient l'impl�mentation de la classe Surface
**Projet de POO 2001 : Listes d'objets 3D
**Auteurs : Avril   BLAISE
**          Thomas  ROUCH
**          Cyrille HEIT
**ESIL, D�partement ES2I, Promotion 2002
*/

#include "Surface.h"
FXIMPLEMENT_ABSTRACT(Surface,Objet3D,NULL,0)

Surface::Surface()
{

}

Surface::~Surface()
{

}




